export const slsLanguageDefinition = {
	id: 'sls',
	extensions: [ '.sls' ],
	aliases: [ 'sls', 'SLS', 'SLSQuery' ],
	mimetypes: []
};
